import { Note, NoteInput } from '../types';

const STORAGE_KEY = 'notes-app-db-v1';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

export const fetchNotes = async (): Promise<Note[]> => {
  await delay(300);
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const createNote = async (input: NoteInput): Promise<Note> => {
  await delay(300);
  const notes = await fetchNotes();
  
  const newNote: Note = {
    _id: generateId(),
    content: input.content,
    createdAt: Date.now(),
  };

  const updatedNotes = [newNote, ...notes];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedNotes));
  return newNote;
};

export const updateNote = async (id: string, input: NoteInput): Promise<Note> => {
  await delay(200);
  const notes = await fetchNotes();
  const index = notes.findIndex(n => n._id === id);
  
  if (index === -1) throw new Error('Note not found');

  const updatedNote = {
    ...notes[index],
    content: input.content,
    updatedAt: Date.now()
  };

  notes[index] = updatedNote;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  return updatedNote;
};

export const deleteNote = async (id: string): Promise<void> => {
  await delay(200);
  const notes = await fetchNotes();
  const filteredNotes = notes.filter(n => n._id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filteredNotes));
};