import React, { useState, useEffect, useCallback } from 'react';
import { Note, ViewMode } from './types';
import * as db from './services/storageService';
import { NoteModal } from './components/NoteModal';
import { 
  PlusIcon, 
  TrashIcon, 
  PencilIcon, 
  GridIcon, 
  ListIcon, 
  SearchIcon,
  SunIcon,
  MoonIcon
} from './components/Icons';

function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.GRID);
  const [searchQuery, setSearchQuery] = useState('');
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') || 'light';
    }
    return 'light';
  });
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentEditingNote, setCurrentEditingNote] = useState<Note | null>(null);

  // Theme effect
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  // Initialize data
  const loadNotes = useCallback(async () => {
    try {
      const data = await db.fetchNotes();
      setNotes(data);
    } catch (error) {
      console.error('Error loading notes:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNotes();
  }, [loadNotes]);

  // Handlers
  const handleCreate = () => {
    setCurrentEditingNote(null);
    setIsModalOpen(true);
  };

  const handleEdit = (note: Note) => {
    setCurrentEditingNote(note);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this note?')) {
      try {
        await db.deleteNote(id);
        setNotes(prev => prev.filter(n => n._id !== id));
      } catch (error) {
        console.error('Error deleting note:', error);
      }
    }
  };

  const handleSaveNote = async ({ content }: { content: string }) => {
    if (currentEditingNote) {
      // Update
      const updated = await db.updateNote(currentEditingNote._id, { content });
      setNotes(prev => prev.map(n => n._id === updated._id ? updated : n));
    } else {
      // Create
      const created = await db.createNote({ content });
      setNotes(prev => [created, ...prev]);
    }
  };

  // Derived state
  const filteredNotes = notes.filter(note => 
    note.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (ts: number) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(ts));
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-sans transition-colors duration-200">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between h-auto sm:h-20 py-4 sm:py-0 gap-4">
            
            {/* Logo area */}
            <div className="flex items-center gap-3 self-start sm:self-center">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Notes</h1>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-none group">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <SearchIcon className="text-slate-400 dark:text-slate-500 group-focus-within:text-blue-500 transition-colors" />
                </div>
                <input
                  type="text"
                  placeholder="Search notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full sm:w-64 pl-10 pr-4 py-2.5 bg-slate-100 dark:bg-slate-800 border border-transparent dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:bg-white dark:focus:bg-slate-900 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all outline-none placeholder-slate-500"
                />
              </div>

              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-transparent dark:border-slate-700">
                <button
                  onClick={() => setViewMode(ViewMode.GRID)}
                  className={`p-2 rounded-lg transition-all ${viewMode === ViewMode.GRID ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                  aria-label="Grid view"
                >
                  <GridIcon />
                </button>
                <button
                  onClick={() => setViewMode(ViewMode.LIST)}
                  className={`p-2 rounded-lg transition-all ${viewMode === ViewMode.LIST ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                  aria-label="List view"
                >
                  <ListIcon />
                </button>
              </div>
              
              <button
                onClick={toggleTheme}
                className="p-3 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
              </button>

              <button
                onClick={handleCreate}
                className="hidden sm:flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium shadow-lg shadow-blue-500/30 hover:bg-blue-700 hover:scale-105 transition-all"
              >
                <PlusIcon className="w-5 h-5" />
                <span>New Note</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {isLoading ? (
          // Loading Skeleton
          <div className={`grid gap-6 ${viewMode === ViewMode.GRID ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white dark:bg-slate-800 rounded-2xl p-6 h-48 border border-slate-200 dark:border-slate-700 animate-pulse">
                <div className="h-4 bg-slate-100 dark:bg-slate-700 rounded w-3/4 mb-4"></div>
                <div className="h-4 bg-slate-100 dark:bg-slate-700 rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-slate-100 dark:bg-slate-700 rounded w-5/6"></div>
              </div>
            ))}
          </div>
        ) : filteredNotes.length === 0 ? (
          // Empty State
          <div className="flex flex-col items-center justify-center min-h-[50vh] text-center">
            <div className="w-24 h-24 bg-blue-50 dark:bg-blue-900/20 text-blue-200 dark:text-blue-600 rounded-full flex items-center justify-center mb-6">
              <PlusIcon className="w-12 h-12" />
            </div>
            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-2">
              {searchQuery ? 'No notes found' : 'No notes yet'}
            </h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-sm mb-8">
              {searchQuery ? 'Try adjusting your search terms.' : 'Capture your thoughts, ideas, and reminders. Start by creating your first note.'}
            </p>
            {!searchQuery && (
              <button
                onClick={handleCreate}
                className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors"
              >
                Create your first note
              </button>
            )}
          </div>
        ) : (
          // Notes Grid/List
          <div className={`grid gap-5 ${viewMode === ViewMode.GRID ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1 max-w-3xl mx-auto'}`}>
            {filteredNotes.map((note) => (
              <div
                key={note._id}
                onClick={() => handleEdit(note)}
                className={`
                  group relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500 rounded-2xl p-5 
                  transition-all duration-200 hover:shadow-xl hover:shadow-slate-200/50 dark:hover:shadow-slate-900/50 hover:-translate-y-1 cursor-pointer
                  flex flex-col justify-between
                  ${viewMode === ViewMode.GRID ? 'h-64' : 'h-auto min-h-[140px]'}
                `}
              >
                <div className="overflow-hidden mb-4">
                  <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed line-clamp-6 text-[15px]">
                    {note.content}
                  </p>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-slate-50 dark:border-slate-700/50 mt-auto">
                  <span className="text-xs font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wide">
                    {formatDate(note.createdAt)}
                  </span>
                  
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => { e.stopPropagation(); handleEdit(note); }}
                      className="p-2 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors"
                      title="Edit"
                    >
                      <PencilIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => handleDelete(note._id, e)}
                      className="p-2 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Floating Action Button (Mobile) */}
      <button
        onClick={handleCreate}
        className="fixed sm:hidden bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg shadow-blue-600/40 flex items-center justify-center z-40 hover:scale-110 transition-transform"
      >
        <PlusIcon />
      </button>

      {/* Modal */}
      <NoteModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveNote}
        initialNote={currentEditingNote}
      />
    </div>
  );
}

export default App;