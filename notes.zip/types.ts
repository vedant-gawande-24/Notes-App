// Data model representing a Note
export interface Note {
  _id: string;
  content: string;
  createdAt: number; // Unix timestamp
  updatedAt?: number;
}

export type NoteInput = Pick<Note, 'content'>;

export enum ViewMode {
  GRID = 'GRID',
  LIST = 'LIST'
}